-- LocalScript: StarterPlayer/StarterPlayerScripts/AbilityController
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")

local Remotes = require(ReplicatedStorage:WaitForChild("Modules"):WaitForChild("Remotes"))

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

local SLOTS = {
	{ Name = "Dash",     Key = Enum.KeyCode.Q, Label = "Q", NeedsAim = false },
	{ Name = "Fireball", Key = Enum.KeyCode.E, Label = "E", NeedsAim = true },
}

local readyAt = {} -- ability name -> os.clock() when we expect it to be ready again (only to avoid useless requests)
local fills = {}   -- ability name -> the cooldown overlay Frame

---------------------------------------------------------------- HUD
local gui = Instance.new("ScreenGui")
gui.Name = "AbilityGui"
gui.ResetOnSpawn = false
gui.Parent = playerGui

local holder = Instance.new("Frame")
holder.AnchorPoint = Vector2.new(0.5, 1)
holder.Position = UDim2.new(0.5, 0, 1, -70)
holder.Size = UDim2.fromOffset(150, 64)
holder.BackgroundTransparency = 1
holder.Parent = gui

local layout = Instance.new("UIListLayout")
layout.FillDirection = Enum.FillDirection.Horizontal
layout.Padding = UDim.new(0, 10)
layout.HorizontalAlignment = Enum.HorizontalAlignment.Center
layout.Parent = holder

for index, slot in SLOTS do
	local box = Instance.new("Frame")
	box.Size = UDim2.fromOffset(64, 64)
	box.BackgroundColor3 = Color3.fromRGB(30, 30, 35)
	box.LayoutOrder = index
	box.ClipsDescendants = true
	box.Parent = holder
	Instance.new("UICorner").Parent = box

	local fill = Instance.new("Frame") -- dark overlay that shrinks as the cooldown runs out
	fill.AnchorPoint = Vector2.new(0, 1)
	fill.Position = UDim2.fromScale(0, 1)
	fill.Size = UDim2.fromScale(1, 0)
	fill.BackgroundColor3 = Color3.new(0, 0, 0)
	fill.BackgroundTransparency = 0.4
	fill.BorderSizePixel = 0
	fill.ZIndex = 2
	fill.Parent = box
	fills[slot.Name] = fill

	local label = Instance.new("TextLabel")
	label.Size = UDim2.fromScale(1, 1)
	label.BackgroundTransparency = 1
	label.Font = Enum.Font.GothamBold
	label.TextSize = 14
	label.TextColor3 = Color3.new(1, 1, 1)
	label.Text = slot.Label .. "\n" .. slot.Name
	label.ZIndex = 3
	label.Parent = box
end

---------------------------------------------------------------- Aiming
local function getMouseWorldPosition(): Vector3
	local camera = workspace.CurrentCamera
	local mouse = UserInputService:GetMouseLocation()
	local ray = camera:ViewportPointToRay(mouse.X, mouse.Y)

	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.FilterDescendantsInstances = { player.Character }

	local result = workspace:Raycast(ray.Origin, ray.Direction * 500, params)
	return if result then result.Position else ray.Origin + ray.Direction * 500
end

---------------------------------------------------------------- Input + feedback
UserInputService.InputBegan:Connect(function(input, gameProcessed)
	if gameProcessed then
		return
	end
	for _, slot in SLOTS do
		if input.KeyCode == slot.Key then
			if os.clock() < (readyAt[slot.Name] or 0) then
				return -- still cooling down; the server would refuse anyway
			end
			Remotes.UseAbility:FireServer(slot.Name, if slot.NeedsAim then getMouseWorldPosition() else nil)
			return
		end
	end
end)

-- The server confirms the ability fired -> start the cooldown animation
Remotes.AbilityUsed.OnClientEvent:Connect(function(abilityName, cooldown)
	local fill = fills[abilityName]
	if not fill then
		return
	end
	readyAt[abilityName] = os.clock() + cooldown

	fill.Size = UDim2.fromScale(1, 1)
	TweenService:Create(fill, TweenInfo.new(cooldown, Enum.EasingStyle.Linear), { Size = UDim2.fromScale(1, 0) }):Play()
end)
