-- LocalScript: StarterPlayer/StarterPlayerScripts/InventoryController
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local ItemConfig = require(Modules:WaitForChild("ItemConfig"))
local Remotes = require(Modules:WaitForChild("Remotes"))

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

local state = { Coins = 0, Items = {}, Equipped = nil }
local currentTab = "Inventory"
local panelOpen = false

-- Small helper: create an instance, set properties, then parent it last
local function make(className: string, props: { [string]: any }, parent: Instance?)
	local instance = Instance.new(className)
	for key, value in props do
		instance[key] = value
	end
	instance.Parent = parent
	return instance
end

local function corner(parent: Instance, radius: number?)
	make("UICorner", { CornerRadius = UDim.new(0, radius or 8) }, parent)
end

---------------------------------------------------------------- UI build
local gui = make("ScreenGui", { Name = "InventoryGui", ResetOnSpawn = false }, playerGui)

local coinsLabel = make("TextLabel", {
	Size = UDim2.fromOffset(160, 36),
	Position = UDim2.new(1, -170, 0, 10),
	BackgroundColor3 = Color3.fromRGB(30, 30, 35),
	TextColor3 = Color3.fromRGB(255, 215, 0),
	Font = Enum.Font.GothamBold,
	TextSize = 18,
	Text = "Coins: 0",
}, gui)
corner(coinsLabel)

local toggleButton = make("TextButton", {
	Size = UDim2.fromOffset(150, 36),
	Position = UDim2.new(0, 10, 1, -46),
	BackgroundColor3 = Color3.fromRGB(30, 30, 35),
	TextColor3 = Color3.new(1, 1, 1),
	Font = Enum.Font.GothamBold,
	TextSize = 16,
	Text = "Inventory [B]",
}, gui)
corner(toggleButton)

-- CanvasGroup lets us fade the whole panel with one property
local panel = make("CanvasGroup", {
	AnchorPoint = Vector2.new(0.5, 0.5),
	Position = UDim2.fromScale(0.5, 0.55),
	Size = UDim2.fromOffset(420, 360),
	BackgroundColor3 = Color3.fromRGB(25, 25, 30),
	GroupTransparency = 1,
	Visible = false,
}, gui)
corner(panel, 12)

local tabBar = make("Frame", { Size = UDim2.new(1, 0, 0, 40), BackgroundTransparency = 1 }, panel)
local function makeTab(text: string, xScale: number)
	return make("TextButton", {
		Size = UDim2.fromScale(0.5, 1),
		Position = UDim2.fromScale(xScale, 0),
		BackgroundColor3 = Color3.fromRGB(35, 35, 42),
		BorderSizePixel = 0,
		TextColor3 = Color3.new(1, 1, 1),
		Font = Enum.Font.GothamBold,
		TextSize = 16,
		Text = text,
	}, tabBar)
end
local inventoryTab = makeTab("Inventory", 0)
local shopTab = makeTab("Shop", 0.5)

local list = make("ScrollingFrame", {
	Position = UDim2.fromOffset(0, 44),
	Size = UDim2.new(1, 0, 1, -44),
	BackgroundTransparency = 1,
	BorderSizePixel = 0,
	CanvasSize = UDim2.new(),
	AutomaticCanvasSize = Enum.AutomaticSize.Y,
	ScrollBarThickness = 6,
}, panel)
make("UIListLayout", { Padding = UDim.new(0, 6), SortOrder = Enum.SortOrder.LayoutOrder }, list)
make("UIPadding", { PaddingTop = UDim.new(0, 8), PaddingLeft = UDim.new(0, 8), PaddingRight = UDim.new(0, 8) }, list)

local function createRow(order: number, title: string, subtitle: string, accent: Color3, buttonText: string, onClick: () -> ())
	local row = make("Frame", {
		Size = UDim2.new(1, -8, 0, 52),
		BackgroundColor3 = Color3.fromRGB(40, 40, 48),
		LayoutOrder = order,
	}, list)
	corner(row)
	make("Frame", { Size = UDim2.new(0, 5, 1, 0), BackgroundColor3 = accent, BorderSizePixel = 0 }, row)
	make("TextLabel", {
		Position = UDim2.fromOffset(14, 4), Size = UDim2.new(1, -120, 0, 24),
		BackgroundTransparency = 1, Text = title, TextXAlignment = Enum.TextXAlignment.Left,
		Font = Enum.Font.GothamBold, TextSize = 16, TextColor3 = Color3.new(1, 1, 1),
	}, row)
	make("TextLabel", {
		Position = UDim2.fromOffset(14, 28), Size = UDim2.new(1, -120, 0, 18),
		BackgroundTransparency = 1, Text = subtitle, TextXAlignment = Enum.TextXAlignment.Left,
		Font = Enum.Font.Gotham, TextSize = 13, TextColor3 = Color3.fromRGB(170, 170, 180),
	}, row)
	local button = make("TextButton", {
		AnchorPoint = Vector2.new(1, 0.5), Position = UDim2.new(1, -8, 0.5, 0), Size = UDim2.fromOffset(90, 32),
		BackgroundColor3 = Color3.fromRGB(60, 120, 220), TextColor3 = Color3.new(1, 1, 1),
		Font = Enum.Font.GothamBold, TextSize = 14, Text = buttonText,
	}, row)
	corner(button, 6)
	button.Activated:Connect(onClick)
end

---------------------------------------------------------------- Rendering
local function sortedKeys(tbl: { [string]: any }): { string }
	local keys = {}
	for key in tbl do
		table.insert(keys, key)
	end
	table.sort(keys)
	return keys
end

local function render()
	coinsLabel.Text = "Coins: " .. state.Coins

	for _, child in list:GetChildren() do
		if child:IsA("Frame") then -- rows are Frames; the layout/padding objects are not
			child:Destroy()
		end
	end

	local order = 0
	if currentTab == "Inventory" then
		for _, itemId in sortedKeys(state.Items) do
			local item = ItemConfig.Items[itemId]
			if item then
				order += 1
				local count = state.Items[itemId]
				local equipped = state.Equipped == itemId
				createRow(
					order,
					item.Name .. (if count > 1 then " x" .. count else ""),
					string.format("%s | Damage %d | Cooldown %.1fs", item.Rarity, item.Damage, item.Cooldown),
					ItemConfig.RarityColors[item.Rarity],
					if equipped then "Unequip" else "Equip",
					function()
						Remotes.EquipItem:FireServer(if equipped then nil else itemId)
					end
				)
			end
		end
	else
		order += 1
		createRow(order, "Mystery Crate", "Random weapon: Common, Rare or Epic",
			Color3.fromRGB(255, 215, 0), "Open (" .. ItemConfig.CratePrice .. ")",
			function() Remotes.OpenCrate:FireServer() end)

		for _, itemId in sortedKeys(ItemConfig.Items) do
			local item = ItemConfig.Items[itemId]
			order += 1
			local owned = (state.Items[itemId] or 0) > 0
			createRow(order, item.Name, string.format("%s | Damage %d", item.Rarity, item.Damage),
				ItemConfig.RarityColors[item.Rarity],
				if owned then "Owned" else "Buy (" .. item.Price .. ")",
				function()
					if not owned then
						Remotes.BuyItem:FireServer(itemId)
					end
				end)
		end
	end
end

---------------------------------------------------------------- Open / close with a tween
local function setOpen(open: boolean)
	panelOpen = open
	if open then
		panel.Visible = true
	end
	local tween = TweenService:Create(panel, TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		GroupTransparency = if open then 0 else 1,
		Position = if open then UDim2.fromScale(0.5, 0.5) else UDim2.fromScale(0.5, 0.55),
	})
	tween:Play()
	if not open then
		tween.Completed:Once(function()
			if not panelOpen then
				panel.Visible = false
			end
		end)
	end
end

local function showToast(text: string, color: Color3)
	local toast = make("TextLabel", {
		AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.new(0.5, 0, 0, 60), Size = UDim2.fromOffset(340, 40),
		BackgroundColor3 = Color3.fromRGB(25, 25, 30), TextColor3 = color,
		Font = Enum.Font.GothamBold, TextSize = 18, Text = text,
	}, gui)
	corner(toast)
	task.delay(2.5, function()
		local fade = TweenService:Create(toast, TweenInfo.new(0.4), { BackgroundTransparency = 1, TextTransparency = 1 })
		fade:Play()
		fade.Completed:Wait()
		toast:Destroy()
	end)
end

---------------------------------------------------------------- Input + remotes
inventoryTab.Activated:Connect(function() currentTab = "Inventory"; render() end)
shopTab.Activated:Connect(function() currentTab = "Shop"; render() end)
toggleButton.Activated:Connect(function() setOpen(not panelOpen) end)

UserInputService.InputBegan:Connect(function(input, gameProcessed)
	if gameProcessed then
		return
	end
	if input.KeyCode == Enum.KeyCode.B then
		setOpen(not panelOpen)
	end
end)

Remotes.StateChanged.OnClientEvent:Connect(function(newState)
	state = newState
	render()
end)

Remotes.CrateResult.OnClientEvent:Connect(function(itemId)
	local item = ItemConfig.Items[itemId]
	if item then
		showToast("You got: " .. item.Name .. " (" .. item.Rarity .. ")", ItemConfig.RarityColors[item.Rarity])
	end
end)

---------------------------------------------------------------- Swing animation
local animationTracks = {} -- animation id -> loaded track (cleared on respawn)

local function playSwing(tool: Tool)
	local itemId = tool:GetAttribute("ItemId")
	local item = itemId and ItemConfig.Items[itemId]
	if not item or not item.SwingAnimation or item.SwingAnimation == "" then
		return -- no animation set for this weapon
	end

	local humanoid = player.Character and player.Character:FindFirstChildOfClass("Humanoid")
	local animator = humanoid and humanoid:FindFirstChildOfClass("Animator")
	if not animator then
		return
	end

	local track = animationTracks[item.SwingAnimation]
	if not track then
		local animation = Instance.new("Animation")
		animation.AnimationId = item.SwingAnimation
		track = animator:LoadAnimation(animation)
		track.Priority = Enum.AnimationPriority.Action -- overrides the idle/walk pose
		animationTracks[item.SwingAnimation] = track
	end

	track:Play()
end

---------------------------------------------------------------- Weapon swinging
-- Hook each weapon Tool once. The Tool moves between Backpack and Character on every
-- equip, so we remember which ones we've already connected.
local hooked = setmetatable({}, { __mode = "k" })

local function hookTool(tool: Tool)
	if hooked[tool] or not tool:GetAttribute("IsWeapon") then
		return
	end
	hooked[tool] = true
	tool.Activated:Connect(function()
		Remotes.Attack:FireServer() -- no arguments: the server works out everything itself
		playSwing(tool)
	end)
end

local function hookCharacter(character: Model)
	table.clear(animationTracks) -- old tracks belonged to the old character
	character.ChildAdded:Connect(function(child)
		if child:IsA("Tool") then
			hookTool(child)
		end
	end)
end

player.CharacterAdded:Connect(hookCharacter)
if player.Character then
	hookCharacter(player.Character)
end

---------------------------------------------------------------- Start
render()
Remotes.RequestState:FireServer() -- ask for our data (connections above are already listening)
