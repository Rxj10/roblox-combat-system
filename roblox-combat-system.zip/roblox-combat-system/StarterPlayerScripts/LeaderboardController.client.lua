-- LocalScript: StarterPlayer/StarterPlayerScripts/LeaderboardController
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Remotes = require(ReplicatedStorage:WaitForChild("Modules"):WaitForChild("Remotes"))

local playerGui = Players.LocalPlayer:WaitForChild("PlayerGui")

local gui = Instance.new("ScreenGui")
gui.Name = "LeaderboardGui"
gui.ResetOnSpawn = false
gui.Parent = playerGui

local frame = Instance.new("Frame")
frame.Position = UDim2.new(1, -210, 0, 56) -- under the coins label
frame.Size = UDim2.fromOffset(200, 30)
frame.AutomaticSize = Enum.AutomaticSize.Y
frame.BackgroundColor3 = Color3.fromRGB(25, 25, 30)
frame.BackgroundTransparency = 0.15
frame.Parent = gui
Instance.new("UICorner").Parent = frame

local layout = Instance.new("UIListLayout")
layout.SortOrder = Enum.SortOrder.LayoutOrder
layout.Padding = UDim.new(0, 2)
layout.Parent = frame

local padding = Instance.new("UIPadding")
padding.PaddingTop = UDim.new(0, 6)
padding.PaddingBottom = UDim.new(0, 6)
padding.PaddingLeft = UDim.new(0, 8)
padding.PaddingRight = UDim.new(0, 8)
padding.Parent = frame

local function addLabel(text: string, order: number, bold: boolean, color: Color3)
	local label = Instance.new("TextLabel")
	label.Size = UDim2.new(1, 0, 0, 18)
	label.BackgroundTransparency = 1
	label.TextXAlignment = Enum.TextXAlignment.Left
	label.Font = if bold then Enum.Font.GothamBold else Enum.Font.Gotham
	label.TextSize = 14
	label.TextColor3 = color
	label.Text = text
	label.LayoutOrder = order
	label.Parent = frame
end

local function render(entries)
	for _, child in frame:GetChildren() do
		if child:IsA("TextLabel") then
			child:Destroy()
		end
	end

	addLabel("Top Kills", 0, true, Color3.fromRGB(255, 215, 0))
	if #entries == 0 then
		addLabel("No data yet", 1, false, Color3.fromRGB(170, 170, 180))
		return
	end
	for rank, entry in entries do
		addLabel(string.format("%d. %s  -  %d", rank, entry.Name, entry.Kills), rank, false, Color3.new(1, 1, 1))
	end
end

Remotes.LeaderboardUpdated.OnClientEvent:Connect(render)

render({})
Remotes.RequestLeaderboard:FireServer()
