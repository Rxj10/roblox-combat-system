-- ModuleScript: ReplicatedStorage/Modules/Inventory
local Inventory = {}
Inventory.__index = Inventory -- failed lookups on an object fall back to this table (that's how methods work)

function Inventory.new(data)
	local self = setmetatable({}, Inventory)
	self.Data = data
	data.Items = data.Items or {}
	return self
end

function Inventory:AddItem(itemId: string, amount: number?)
	amount = amount or 1
	self.Data.Items[itemId] = (self.Data.Items[itemId] or 0) + amount
end

function Inventory:RemoveItem(itemId: string, amount: number?): boolean
	amount = amount or 1
	local have = self.Data.Items[itemId] or 0
	if have < amount then
		return false
	end
	local left = have - amount
	self.Data.Items[itemId] = if left > 0 then left else nil
	if left <= 0 and self.Data.Equipped == itemId then
		self.Data.Equipped = nil
	end
	return true
end

function Inventory:HasItem(itemId: string, amount: number?): boolean
	return (self.Data.Items[itemId] or 0) >= (amount or 1)
end

function Inventory:Equip(itemId: string): boolean
	if not self:HasItem(itemId) then
		return false
	end
	self.Data.Equipped = itemId
	return true
end

function Inventory:Unequip()
	self.Data.Equipped = nil
end

function Inventory:GetEquipped(): string?
	return self.Data.Equipped
end

-- A copy, so outside code can't change the real table by accident
function Inventory:GetItems(): { [string]: number }
	local copy = {}
	for itemId, count in pairs(self.Data.Items) do
		copy[itemId] = count
	end
	return copy
end

return Inventory
