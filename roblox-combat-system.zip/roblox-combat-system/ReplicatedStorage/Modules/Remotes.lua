-- ModuleScript: ReplicatedStorage/Modules/Remotes
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local NAMES = {
	"EquipItem",          -- client -> server: equip/unequip an item
	"Attack",             -- client -> server: "I swung my weapon" (no arguments)
	"BuyItem",            -- client -> server: buy a specific item
	"OpenCrate",          -- client -> server: open a loot crate
	"RequestState",       -- client -> server: "send me my data"
	"StateChanged",       -- server -> client: coins/items/equipped
	"CrateResult",        -- server -> client: what the crate gave you
	"UseAbility",         -- client -> server: ability name + optional aim position
	"AbilityUsed",        -- server -> client: ability name + cooldown (for the HUD)
	"LeaderboardUpdated", -- server -> client: top 10 list
	"RequestLeaderboard", -- client -> server: "send me the current top 10"
}

local Remotes = {}

if RunService:IsServer() then
	local folder = Instance.new("Folder")
	folder.Name = "Remotes"
	for _, name in NAMES do
		local remote = Instance.new("RemoteEvent")
		remote.Name = name
		remote.Parent = folder
		Remotes[name] = remote
	end
	folder.Parent = ReplicatedStorage
else
	local folder = ReplicatedStorage:WaitForChild("Remotes")
	for _, name in NAMES do
		Remotes[name] = folder:WaitForChild(name)
	end
end

return Remotes
