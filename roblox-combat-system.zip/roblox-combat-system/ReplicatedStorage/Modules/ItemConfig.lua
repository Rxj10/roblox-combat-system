-- ModuleScript: ReplicatedStorage/Modules/ItemConfig
--!strict
export type ItemData = {
	Name: string,
	Damage: number,
	Cooldown: number, -- seconds between swings
	Range: number,    -- studs
	Rarity: string,
	Price: number,
	SwingAnimation: string?, -- animation ID like "rbxassetid://123456789" ("" or missing = no animation)
}

local Items: { [string]: ItemData } = {
	WoodSword = {
		Name = "Wood Sword", Damage = 10, Cooldown = 0.6, Range = 6, Rarity = "Common", Price = 50,
		SwingAnimation = "", -- paste your animation ID here
	},
	IronSword = {
		Name = "Iron Sword", Damage = 20, Cooldown = 0.5, Range = 6.5, Rarity = "Rare", Price = 250,
		SwingAnimation = "",
	},
	GoldSword = {
		Name = "Gold Sword", Damage = 35, Cooldown = 0.4, Range = 7, Rarity = "Epic", Price = 1000,
		SwingAnimation = "",
	},
}

return {
	Items = Items,
	CratePrice = 100,
	-- Relative chances (they don't have to add up to 100)
	RarityWeights = { Common = 70, Rare = 25, Epic = 5 },
	RarityColors = {
		Common = Color3.fromRGB(200, 200, 200),
		Rare = Color3.fromRGB(70, 130, 255),
		Epic = Color3.fromRGB(170, 70, 255),
	},
}
