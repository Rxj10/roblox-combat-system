# <Game Name>: Weapon, Ability & Inventory System

A server-authoritative combat and inventory framework for Roblox, written in Luau.

**Play it:** <paste your Roblox game link>

![Gameplay](<screenshot-or-gif-link>)

## Controls

| Key | Action |
|---|---|
| Click | Swing equipped weapon |
| Q | Dash |
| E | Fireball (aims at the mouse) |
| B | Open inventory / shop |

## Features

- **Persistent data:** coins, items, equipped weapon and kill count are saved with DataStores.
- **Inventory (OOP):** an `Inventory` class built with metatables.
- **Weapons:** server-side hit detection, server-enforced cooldowns, optional custom models and swing animations.
- **Abilities:** a base `Ability` class with `Dash` and `Fireball` subclasses (inheritance).
- **Shop and loot crates:** validated purchases and rarity-weighted random drops.
- **Kills leaderboard:** `OrderedDataStore` with throttled reads/writes and caching.
- **UI:** inventory/shop panel and ability cooldown HUD, built entirely in code with tweens.

## How it works

The client only *requests* actions, and the server decides what happens.

| System | Where | What it does |
|---|---|---|
| DataService | `ServerScriptService/Services` | Loads/saves player data using `UpdateAsync`, a session lock, retries with backoff, autosave and `BindToClose` |
| InventoryService / Inventory | `Services` / `ReplicatedStorage/Modules` | Per-player inventory object that holds a reference to the saved data, so changes are saved automatically |
| CombatService | `Services` | Validates each attack, then builds a hitbox with `GetPartBoundsInBox` |
| AbilityService + Abilities | `Services` | Validates ability requests; `Ability` is the base class, `Dash` and `Fireball` override `Activate()` |
| ShopService | `Services` | Validates purchases and rolls crate drops |
| LeaderboardService | `Services` | Writes kills to an `OrderedDataStore` once a minute, caches the top 10 |
| RateLimit | `Services` | Small per-player, per-action rate limiter |
| Remotes | `ReplicatedStorage/Modules` | Creates RemoteEvents on the server and looks them up on the client |
| ItemConfig | `ReplicatedStorage/Modules` | Single source of truth for item stats |

## Security

- Every RemoteEvent validates argument **types** first, then **values**.
- Damage, cooldowns, range and prices come from the server's config and never from the client.
- `Attack` takes no arguments, so there is nothing for an exploiter to spoof.
- Aim positions for `Fireball` are checked for NaN and infinity, and only the *direction* is used.
- Remotes that change state are rate limited per player.
- The weapon in the player's hand is checked against the server's inventory data.
- I tested the remotes with a script that sends bad data, spam and unowned items.

## Project structure

```
ServerScriptService/
  Main
  DummyRespawner
  Services/
    DataService, InventoryService, CombatService, AbilityService,
    ShopService, LeaderboardService, Rewards, RateLimit
    Abilities/ Ability, Dash, Fireball
ReplicatedStorage/Modules/
  Remotes, ItemConfig, Inventory
StarterPlayerScripts/
  InventoryController, AbilityController, LeaderboardController
tests/
  ExploitTest, ExploitTest2   (temporary scripts that fire bad data at the remotes)
```

## Adding content

- **New item:** add an entry to `ItemConfig.Items` (and optionally a Tool named after the item ID in `ServerStorage/Weapons`). The shop, crates, UI and combat pick it up automatically.
- **New ability:** create a subclass of `Ability` that overrides `Activate()`, then add it to the `abilities` table in `AbilityService`.

## What I'd improve next

- <write your own ideas, for example: trading between players, saved ability loadouts, data versioning/migrations>

## Notes

<Write honestly how you built this. For example: "I wrote and tested this project myself, and I used AI tools to learn patterns and review code. I understand and can explain every script." Only write what is true, and follow the rules of the server you're applying to.>

## Setup (to run it in Studio)

1. Publish the place and enable **Game Settings → Security → Studio Access to API Services**.
2. Copy the scripts into the folders shown in the structure above.
3. Place some R15 rigs named `Dummy` in the workspace as practice targets.
