-- Script: ServerScriptService/DummyRespawner
for _, dummy in workspace:GetChildren() do
	if dummy.Name == "Dummy" and dummy:FindFirstChildOfClass("Humanoid") then
		local template = dummy:Clone()

		local function watch(model)
			model.Humanoid.Died:Once(function()
				task.wait(3)
				model:Destroy()
				local fresh = template:Clone()
				fresh.Parent = workspace
				watch(fresh)
			end)
		end

		watch(dummy)
	end
end
