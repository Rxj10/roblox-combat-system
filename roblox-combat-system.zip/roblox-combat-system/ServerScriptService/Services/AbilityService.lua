-- ModuleScript: ServerScriptService/Services/AbilityService
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Remotes = require(ReplicatedStorage:WaitForChild("Modules").Remotes)

local RateLimit = require(script.Parent.RateLimit)
local Dash = require(script.Parent.Abilities.Dash)
local Fireball = require(script.Parent.Abilities.Fireball)

local AbilityService = {}

-- Adding a new ability = write a subclass + add one line here
local abilities = {
	Dash = Dash.new(),
	Fireball = Fireball.new(),
}

-- A Vector3 sent by a client can still be NaN or infinite, so check for that
local function isValidPosition(value: any): boolean
	return typeof(value) == "Vector3"
		and value.X == value.X and value.Y == value.Y and value.Z == value.Z -- NaN is never equal to itself
		and value.Magnitude < 1e5 -- also rejects infinity
end

function AbilityService.Init()
	Remotes.UseAbility.OnServerEvent:Connect(function(player, abilityName, targetPosition)
		if not RateLimit.Check(player, "Ability", 0.1) then
			return
		end
		if typeof(abilityName) ~= "string" then
			return
		end
		local ability = abilities[abilityName]
		if not ability then
			return
		end
		if targetPosition ~= nil and not isValidPosition(targetPosition) then
			return
		end

		if ability:Use(player, targetPosition) then
			Remotes.AbilityUsed:FireClient(player, abilityName, ability.Cooldown)
		end
	end)
end

function AbilityService.Cleanup(player: Player)
	for _, ability in abilities do
		ability:Cleanup(player)
	end
end

return AbilityService
