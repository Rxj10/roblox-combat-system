-- ModuleScript: ServerScriptService/Services/RateLimit
local RateLimit = {}

local lastUse = {} -- [Player] = { [key] = os.clock() of last allowed use }

-- Returns true if allowed, false if the player is doing this too fast
function RateLimit.Check(player: Player, key: string, interval: number): boolean
	local now = os.clock()
	local bucket = lastUse[player]
	if not bucket then
		bucket = {}
		lastUse[player] = bucket
	end
	local previous = bucket[key]
	if previous and now - previous < interval then
		return false
	end
	bucket[key] = now
	return true
end

function RateLimit.Cleanup(player: Player)
	lastUse[player] = nil
end

return RateLimit
