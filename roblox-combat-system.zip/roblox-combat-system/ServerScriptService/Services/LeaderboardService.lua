-- ModuleScript: ServerScriptService/Services/LeaderboardService
local DataStoreService = game:GetService("DataStoreService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Remotes = require(ReplicatedStorage:WaitForChild("Modules").Remotes)
local DataService = require(script.Parent.DataService)

local board = DataStoreService:GetOrderedDataStore("Kills_v1")

local REFRESH_SECONDS = 60
local TOP_COUNT = 10

local LeaderboardService = {}

local latest = {}     -- cached top list: { { Name = string, Kills = number }, ... }
local nameCache = {}  -- [userId] = username (so we don't ask Roblox for the same name again)

local function getName(userId: number): string
	if nameCache[userId] then
		return nameCache[userId]
	end
	local ok, name = pcall(Players.GetNameFromUserIdAsync, Players, userId)
	if ok then
		nameCache[userId] = name
		return name
	end
	return "Unknown"
end

-- Writes one player's kill count to the ordered store
function LeaderboardService.Submit(player: Player)
	local data = DataService.Get(player) -- read right away, before the player's data is released
	if not data then
		return
	end
	local kills = data.Kills or 0
	local ok, err = pcall(function()
		board:SetAsync(tostring(player.UserId), kills)
	end)
	if not ok then
		warn("Leaderboard write failed: " .. tostring(err))
	end
end

local function refresh()
	for _, player in Players:GetPlayers() do
		LeaderboardService.Submit(player)
	end

	local ok, pages = pcall(function()
		return board:GetSortedAsync(false, TOP_COUNT) -- false = highest first
	end)
	if not ok then
		warn("Leaderboard read failed: " .. tostring(pages))
		return
	end

	local entries = {}
	for _, entry in pages:GetCurrentPage() do
		table.insert(entries, { Name = getName(tonumber(entry.key) :: number), Kills = entry.value })
	end

	latest = entries
	Remotes.LeaderboardUpdated:FireAllClients(entries)
end

function LeaderboardService.Init()
	Remotes.RequestLeaderboard.OnServerEvent:Connect(function(player)
		Remotes.LeaderboardUpdated:FireClient(player, latest)
	end)

	task.spawn(function()
		while true do
			refresh()
			task.wait(REFRESH_SECONDS)
		end
	end)
end

return LeaderboardService
