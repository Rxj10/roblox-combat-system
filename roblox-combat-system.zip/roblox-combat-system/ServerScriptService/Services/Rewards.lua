-- ModuleScript: ServerScriptService/Services/Rewards
local DataService = require(script.Parent.DataService)
local InventoryService = require(script.Parent.InventoryService)

local KILL_REWARD = 10 -- default gold per kill
-- Tip: give a dummy a number attribute called "Reward" to override this for that target

local Rewards = {}

function Rewards.GrantKill(player: Player, victimModel: Model)
	local data = DataService.Get(player)
	if not data then
		return -- player left or data not loaded
	end

	local reward = victimModel:GetAttribute("Reward")
	if type(reward) ~= "number" then
		reward = KILL_REWARD
	end

	data.Coins += reward
	data.Kills = (data.Kills or 0) + 1
	InventoryService.Push(player)
end

return Rewards
