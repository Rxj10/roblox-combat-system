-- ModuleScript: ServerScriptService/Services/Abilities/Fireball
local RunService = game:GetService("RunService")

local Ability = require(script.Parent.Ability)
local Rewards = require(script.Parent.Parent.Rewards)

local Fireball = setmetatable({}, { __index = Ability })
Fireball.__index = Fireball

local SPEED = 60
local MAX_DISTANCE = 90
local BLAST_RADIUS = 8
local DAMAGE = 25

function Fireball.new()
	return setmetatable(Ability.new("Fireball", 3), Fireball)
end

-- Damages everything near `position` (except the caster) and pays out kills
local function explode(caster: Player, character: Model, position: Vector3)
	-- Visual only: no pressure and no joint breaking
	local explosion = Instance.new("Explosion")
	explosion.Position = position
	explosion.BlastRadius = BLAST_RADIUS
	explosion.BlastPressure = 0
	explosion.DestroyJointRadiusPercent = 0
	explosion.Parent = workspace

	local params = OverlapParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.FilterDescendantsInstances = { character }

	local hit = {} -- one hit per target, even if several of its parts are in range
	for _, part in workspace:GetPartBoundsInRadius(position, BLAST_RADIUS, params) do
		local model = part:FindFirstAncestorOfClass("Model")
		local humanoid = model and model:FindFirstChildOfClass("Humanoid")
		if model and humanoid and not hit[humanoid] and humanoid.Health > 0 then
			hit[humanoid] = true
			humanoid:TakeDamage(DAMAGE)
			if humanoid.Health <= 0 then
				Rewards.GrantKill(caster, model)
			end
		end
	end
end

function Fireball:Activate(player: Player, character: Model, targetPosition: Vector3?): boolean
	local root = character:FindFirstChild("HumanoidRootPart")
	if not root or not targetPosition then
		return false
	end

	local origin = root.Position + Vector3.new(0, 1, 0)
	local offset = targetPosition - origin
	if offset.Magnitude < 1 then
		return false
	end
	local direction = offset.Unit -- only the DIRECTION is used; speed/damage/range are fixed here

	local ball = Instance.new("Part")
	ball.Shape = Enum.PartType.Ball
	ball.Size = Vector3.new(2, 2, 2)
	ball.Material = Enum.Material.Neon
	ball.Color = Color3.fromRGB(255, 120, 30)
	ball.Anchored = true
	ball.CanCollide = false
	ball.CanQuery = false
	ball.CanTouch = false
	ball.Position = origin + direction * 3
	ball.Parent = workspace

	local rayParams = RaycastParams.new()
	rayParams.FilterType = Enum.RaycastFilterType.Exclude
	rayParams.FilterDescendantsInstances = { character, ball }

	local travelled = 0
	local connection: RBXScriptConnection

	local function finish(position: Vector3)
		connection:Disconnect()
		ball:Destroy()
		explode(player, character, position)
	end

	connection = RunService.Heartbeat:Connect(function(dt)
		local step = direction * SPEED * dt
		local result = workspace:Raycast(ball.Position, step, rayParams)
		if result then
			finish(result.Position)
			return
		end

		ball.Position += step
		travelled += step.Magnitude
		if travelled >= MAX_DISTANCE then
			finish(ball.Position)
		end
	end)

	return true
end

return Fireball
