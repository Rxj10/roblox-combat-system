-- ModuleScript: ServerScriptService/Services/Abilities/Dash
local Debris = game:GetService("Debris")

local Ability = require(script.Parent.Ability)

-- Inheritance in Luau: Dash looks things up in Ability when it doesn't have them itself
local Dash = setmetatable({}, { __index = Ability })
Dash.__index = Dash

local SPEED = 80     -- studs/second
local DURATION = 0.2 -- seconds

function Dash.new()
	return setmetatable(Ability.new("Dash", 4), Dash)
end

function Dash:Activate(_player: Player, character: Model, _targetPosition: Vector3?): boolean
	local root = character:FindFirstChild("HumanoidRootPart")
	local humanoid = character:FindFirstChildOfClass("Humanoid")
	if not root or not humanoid then
		return false
	end

	-- Dash where the player is moving, or where they're facing if standing still
	local direction = humanoid.MoveDirection
	if direction.Magnitude < 0.1 then
		direction = root.CFrame.LookVector
	end
	local flat = Vector3.new(direction.X, 0, direction.Z)
	if flat.Magnitude < 0.01 then
		return false
	end

	local attachment = Instance.new("Attachment")
	attachment.Parent = root

	local velocity = Instance.new("LinearVelocity")
	velocity.Attachment0 = attachment
	velocity.MaxForce = math.huge
	velocity.VectorVelocity = flat.Unit * SPEED
	velocity.Parent = root

	-- Debris removes them after DURATION, so nothing is left behind
	Debris:AddItem(attachment, DURATION)
	Debris:AddItem(velocity, DURATION)
	return true
end

return Dash
