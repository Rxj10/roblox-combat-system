-- ModuleScript: ServerScriptService/Services/Abilities/Ability
local Ability = {}
Ability.__index = Ability

function Ability.new(name: string, cooldown: number)
	local self = setmetatable({}, Ability)
	self.Name = name
	self.Cooldown = cooldown
	self._lastUse = {} -- [Player] = os.clock() of the last successful use
	return self
end

function Ability:IsReady(player: Player): boolean
	local last = self._lastUse[player]
	return last == nil or os.clock() - last >= self.Cooldown
end

-- Shared checks. Returns true if the ability actually fired.
function Ability:Use(player: Player, targetPosition: Vector3?): boolean
	local character = player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	if not character or not humanoid or humanoid.Health <= 0 then
		return false
	end
	if not self:IsReady(player) then
		return false
	end

	if not self:Activate(player, character, targetPosition) then
		return false -- the subclass said "can't do it", so no cooldown is spent
	end

	self._lastUse[player] = os.clock()
	return true
end

-- Subclasses MUST override this
function Ability:Activate(_player: Player, _character: Model, _targetPosition: Vector3?): boolean
	error(self.Name .. " must implement Activate()")
end

function Ability:Cleanup(player: Player)
	self._lastUse[player] = nil
end

return Ability
