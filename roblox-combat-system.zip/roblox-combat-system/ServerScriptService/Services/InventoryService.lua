-- ModuleScript: ServerScriptService/Services/InventoryService
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Inventory = require(Modules.Inventory)
local ItemConfig = require(Modules.ItemConfig)
local Remotes = require(Modules.Remotes)

local DataService = require(script.Parent.DataService)
local RateLimit = require(script.Parent.RateLimit)

-- Optional folder with your own Tools, named after the item IDs (WoodSword, IronSword, ...)
-- If it doesn't exist, or an item has no Tool there, a simple generated sword is used.
local weaponsFolder = ServerStorage:FindFirstChild("Weapons")

local InventoryService = {}

local inventories = {} -- [Player] = Inventory object

function InventoryService.Get(player: Player)
	return inventories[player]
end

-- Send the client everything it needs to draw its UI
function InventoryService.Push(player: Player)
	local inventory = inventories[player]
	local data = DataService.Get(player)
	if not inventory or not data then
		return
	end
	Remotes.StateChanged:FireClient(player, {
		Coins = data.Coins,
		Items = inventory:GetItems(),
		Equipped = inventory:GetEquipped(),
	})
end

local function removeWeaponTools(player: Player)
	local containers = { player:FindFirstChildOfClass("Backpack"), player.Character }
	for _, container in containers do
		for _, child in container:GetChildren() do
			if child:IsA("Tool") and child:GetAttribute("IsWeapon") then
				child:Destroy()
			end
		end
	end
end

-- Creates the Tool for an item: your model from ServerStorage/Weapons if there is one,
-- otherwise a simple generated sword
local function createTool(itemId: string, item): Tool
	local template = weaponsFolder and weaponsFolder:FindFirstChild(itemId)
	local tool: Tool

	if template and template:IsA("Tool") then
		tool = template:Clone()
	else
		tool = Instance.new("Tool")
		tool.GripPos = Vector3.new(0, 0, -1.5)

		local handle = Instance.new("Part")
		handle.Name = "Handle"
		handle.Size = Vector3.new(0.4, 0.4, 4)
		handle.Material = Enum.Material.Metal
		handle.Color = ItemConfig.RarityColors[item.Rarity]
		handle.Parent = tool
	end

	tool.Name = item.Name
	tool.CanBeDropped = false
	tool:SetAttribute("IsWeapon", true) -- the combat code and the client look for these two
	tool:SetAttribute("ItemId", itemId)
	return tool
end

local function giveWeaponTool(player: Player)
	-- Skip if the player has no Backpack/Character yet (loading or respawning)
	if not player:FindFirstChildOfClass("Backpack") or not player.Character then
		return
	end

	removeWeaponTools(player)

	local inventory = inventories[player]
	if not inventory then
		return
	end

	local itemId = inventory:GetEquipped()
	local item = itemId and ItemConfig.Items[itemId]
	if not itemId or not item then
		return
	end

	local tool = createTool(itemId, item)
	tool.Parent = player:FindFirstChildOfClass("Backpack")
end

function InventoryService.Setup(player: Player)
	local data = DataService.Get(player)
	inventories[player] = Inventory.new(data)

	player.CharacterAdded:Connect(function()
		task.wait(0.2) -- give Roblox a moment to rebuild the Backpack after respawn
		giveWeaponTool(player)
	end)
	if player.Character then -- the character may have spawned while data was loading
		giveWeaponTool(player)
	end

	InventoryService.Push(player)
end

function InventoryService.Cleanup(player: Player)
	inventories[player] = nil
end

function InventoryService.Init()
	Remotes.RequestState.OnServerEvent:Connect(function(player)
		if RateLimit.Check(player, "RequestState", 1) then
			InventoryService.Push(player)
		end
	end)

	-- itemId is a string to equip, or nil to unequip
	Remotes.EquipItem.OnServerEvent:Connect(function(player, itemId)
		if not RateLimit.Check(player, "Equip", 0.25) then
			return
		end
		local inventory = inventories[player]
		if not inventory then
			return
		end

		local ok = false
		if itemId == nil then
			inventory:Unequip()
			ok = true
		elseif typeof(itemId) == "string" then
			ok = inventory:Equip(itemId) -- fails if the player doesn't own it
		end
		if not ok then
			return
		end

		giveWeaponTool(player)
		InventoryService.Push(player)
	end)
end

return InventoryService
