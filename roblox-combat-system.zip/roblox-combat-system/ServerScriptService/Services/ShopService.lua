-- ModuleScript: ServerScriptService/Services/ShopService
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local ItemConfig = require(Modules.ItemConfig)
local Remotes = require(Modules.Remotes)

local DataService = require(script.Parent.DataService)
local InventoryService = require(script.Parent.InventoryService)
local RateLimit = require(script.Parent.RateLimit)

local ShopService = {}

-- Weighted random: Common 70 / Rare 25 / Epic 5 means a 5/100 chance for Epic.
-- Walk through the weights, subtracting from a random roll until it runs out.
local function pickRarity(): string
	local total = 0
	for _, weight in pairs(ItemConfig.RarityWeights) do
		total += weight
	end
	local roll = math.random() * total
	for rarity, weight in pairs(ItemConfig.RarityWeights) do
		roll -= weight
		if roll <= 0 then
			return rarity
		end
	end
	return "Common"
end

local function pickItemId(): string?
	local rarity = pickRarity()
	local pool = {}
	for itemId, item in pairs(ItemConfig.Items) do
		if item.Rarity == rarity then
			table.insert(pool, itemId)
		end
	end
	if #pool == 0 then
		return nil
	end
	return pool[math.random(1, #pool)]
end

function ShopService.Init()
	Remotes.BuyItem.OnServerEvent:Connect(function(player, itemId)
		if not RateLimit.Check(player, "Buy", 0.3) then
			return
		end
		if typeof(itemId) ~= "string" then
			return
		end
		local item = ItemConfig.Items[itemId]
		local inventory = InventoryService.Get(player)
		local data = DataService.Get(player)
		if not item or not inventory or not data then
			return
		end
		if inventory:HasItem(itemId) or data.Coins < item.Price then
			return
		end

		data.Coins -= item.Price
		inventory:AddItem(itemId, 1)
		InventoryService.Push(player)
	end)

	Remotes.OpenCrate.OnServerEvent:Connect(function(player)
		if not RateLimit.Check(player, "Crate", 0.5) then
			return
		end
		local inventory = InventoryService.Get(player)
		local data = DataService.Get(player)
		if not inventory or not data or data.Coins < ItemConfig.CratePrice then
			return
		end

		local itemId = pickItemId() -- pick first, so a config mistake never costs the player coins
		if not itemId then
			return
		end

		data.Coins -= ItemConfig.CratePrice
		inventory:AddItem(itemId, 1) -- duplicates just stack
		InventoryService.Push(player)
		Remotes.CrateResult:FireClient(player, itemId)
	end)
end

return ShopService
