-- ModuleScript: ServerScriptService/Services/DataService
local DataStoreService = game:GetService("DataStoreService")

local store = DataStoreService:GetDataStore("PlayerData_v1")

local KEY_PREFIX = "Player_"
local LOCK_TIMEOUT = 600 -- seconds before a lock from a crashed server is ignored

-- What a brand-new player starts with
local DEFAULT_DATA = {
	Coins = 100,
	Items = { WoodSword = 1 },
	Equipped = "WoodSword",
}

local DataService = {}

local cache = {}          -- [Player] = their data table (live, in memory)
local pendingWrites = 0   -- how many saves are currently in flight

local function deepCopy(value)
	if type(value) ~= "table" then
		return value
	end
	local copy = {}
	for key, inner in pairs(value) do
		copy[key] = deepCopy(inner)
	end
	return copy
end

-- Runs fn in a pcall, retrying with a growing delay (exponential backoff)
local function retry(fn, attempts)
	local lastError
	for attempt = 1, attempts do
		local ok, result = pcall(fn)
		if ok then
			return true, result
		end
		lastError = result
		warn(string.format("DataStore attempt %d/%d failed: %s", attempt, attempts, tostring(result)))
		if attempt < attempts then
			task.wait(2 ^ attempt * 0.5) -- 1s, 2s, ...
		end
	end
	return false, lastError
end

-- Writes data to the store. If `release` is true, the session lock is cleared.
local function write(userId, data, release)
	pendingWrites += 1
	local snapshot = deepCopy(data) -- freeze the data as it is right now

	local ok = retry(function()
		return store:UpdateAsync(KEY_PREFIX .. userId, function(old)
			-- If another server owns the lock, don't overwrite its data
			if old and old.SessionLock and old.SessionLock ~= game.JobId then
				return nil -- returning nil cancels the update
			end
			snapshot.SessionLock = if release then nil else game.JobId
			snapshot.LockTime = os.time()
			return snapshot
		end)
	end, 3)

	if not ok then
		warn("Failed to save data for user " .. userId)
	end
	pendingWrites -= 1
end

-- Returns true if data loaded and this server now owns the lock
function DataService.Load(player: Player): boolean
	local key = KEY_PREFIX .. player.UserId
	local lockedByOther = false

	local ok, data = retry(function()
		lockedByOther = false
		return store:UpdateAsync(key, function(old)
			old = old or {}
			local lockAge = os.time() - (old.LockTime or 0)
			if old.SessionLock and old.SessionLock ~= game.JobId and lockAge < LOCK_TIMEOUT then
				lockedByOther = true
				return nil
			end
			old.SessionLock = game.JobId
			old.LockTime = os.time()
			return old
		end)
	end, 3)

	if not ok or lockedByOther or type(data) ~= "table" then
		return false
	end

	-- Fill in anything missing for new players
	if data.Coins == nil then
		data.Coins = DEFAULT_DATA.Coins
	end
	if data.Items == nil then
		data.Items = deepCopy(DEFAULT_DATA.Items)
		data.Equipped = DEFAULT_DATA.Equipped
	end
	if data.Kills == nil then -- NEW: kill counter for the leaderboard (also added to old saves)
		data.Kills = 0
	end

	cache[player] = data
	return true
end

function DataService.Get(player: Player)
	return cache[player]
end

-- Save but keep playing (autosave)
function DataService.Save(player: Player)
	local data = cache[player]
	if data then
		write(player.UserId, data, false)
	end
end

-- Final save when a player leaves: also releases the session lock
function DataService.Release(player: Player)
	local data = cache[player]
	if not data then
		return
	end
	cache[player] = nil
	write(player.UserId, data, true)
end

-- Used by BindToClose: save everyone and wait until all writes finish
function DataService.SaveAll()
	local players = {}
	for player in pairs(cache) do
		table.insert(players, player)
	end
	for _, player in players do
		task.spawn(DataService.Release, player)
	end
	while pendingWrites > 0 do
		task.wait()
	end
end

return DataService
