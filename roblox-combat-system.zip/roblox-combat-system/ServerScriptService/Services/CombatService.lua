-- ModuleScript: ServerScriptService/Services/CombatService
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local ItemConfig = require(Modules.ItemConfig)
local Remotes = require(Modules.Remotes)

local InventoryService = require(script.Parent.InventoryService)
local Rewards = require(script.Parent.Rewards)

local CombatService = {}

local LATENCY_TOLERANCE = 0.05 -- seconds of slack so laggy players aren't punished

local lastAttack = {} -- [Player] = os.clock() of the last accepted attack

local overlapParams = OverlapParams.new()
overlapParams.FilterType = Enum.RaycastFilterType.Exclude

local function handleAttack(player: Player)
	-- 1. Is the player alive?
	local character = player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	local root = character and character:FindFirstChild("HumanoidRootPart")
	if not character or not humanoid or not root or humanoid.Health <= 0 then
		return
	end

	-- 2. Do they really have a weapon equipped (according to the SERVER's data)?
	local inventory = InventoryService.Get(player)
	local itemId = inventory and inventory:GetEquipped()
	local item = itemId and ItemConfig.Items[itemId]
	if not item then
		return
	end

	-- 3. Is that weapon actually in their hand right now?
	local tool = character:FindFirstChildOfClass("Tool")
	if not tool or tool:GetAttribute("ItemId") ~= itemId then
		return
	end

	-- 4. Cooldown, enforced on the server
	local now = os.clock()
	local last = lastAttack[player]
	if last and now - last < item.Cooldown - LATENCY_TOLERANCE then
		return
	end
	lastAttack[player] = now

	-- 5. Build the hitbox in front of the player and damage everything inside
	local size = Vector3.new(5, 5, item.Range)
	local hitboxCFrame = root.CFrame * CFrame.new(0, 0, -(item.Range / 2 + 1))
	overlapParams.FilterDescendantsInstances = { character }

	local damaged = {} -- so one swing can't hit the same target twice
	for _, part in workspace:GetPartBoundsInBox(hitboxCFrame, size, overlapParams) do
		local model = part:FindFirstAncestorOfClass("Model")
		local targetHumanoid = model and model:FindFirstChildOfClass("Humanoid")

		if model and targetHumanoid and not damaged[targetHumanoid] and targetHumanoid.Health > 0 then
			damaged[targetHumanoid] = true
			targetHumanoid:TakeDamage(item.Damage) -- damage comes from the config, never the client

			if targetHumanoid.Health <= 0 then
				Rewards.GrantKill(player, model)
			end
		end
	end
end

function CombatService.Init()
	Remotes.Attack.OnServerEvent:Connect(handleAttack)
end

function CombatService.Cleanup(player: Player)
	lastAttack[player] = nil
end

return CombatService
