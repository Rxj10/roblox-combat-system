-- Script: ServerScriptService/Main
local Players = game:GetService("Players")
local ServerScriptService = game:GetService("ServerScriptService")

local Services = ServerScriptService:WaitForChild("Services")
local DataService = require(Services.DataService)
local InventoryService = require(Services.InventoryService)
local CombatService = require(Services.CombatService)
local AbilityService = require(Services.AbilityService)
local ShopService = require(Services.ShopService)
local LeaderboardService = require(Services.LeaderboardService)
local RateLimit = require(Services.RateLimit)

-- Connect remote handlers
InventoryService.Init()
CombatService.Init()
AbilityService.Init()
ShopService.Init()
LeaderboardService.Init()

local function onPlayerAdded(player: Player)
	if not DataService.Load(player) then
		player:Kick("Could not load your data. Please rejoin in a minute.")
		return
	end
	InventoryService.Setup(player)
end

local function onPlayerRemoving(player: Player)
	-- Must run BEFORE DataService.Release: Submit reads the player's data immediately,
	-- then yields while it writes to the leaderboard
	task.spawn(LeaderboardService.Submit, player)

	InventoryService.Cleanup(player)
	CombatService.Cleanup(player)
	AbilityService.Cleanup(player)
	RateLimit.Cleanup(player)
	DataService.Release(player)
end

Players.PlayerAdded:Connect(onPlayerAdded)
for _, player in Players:GetPlayers() do -- players who joined before this script ran
	task.spawn(onPlayerAdded, player)
end
Players.PlayerRemoving:Connect(onPlayerRemoving)

game:BindToClose(function()
	DataService.SaveAll()
end)

-- Autosave every 2 minutes (a loop is fine here: no event exists for "time passed")
task.spawn(function()
	while true do
		task.wait(120)
		for _, player in Players:GetPlayers() do
			task.spawn(DataService.Save, player)
		end
	end
end)
